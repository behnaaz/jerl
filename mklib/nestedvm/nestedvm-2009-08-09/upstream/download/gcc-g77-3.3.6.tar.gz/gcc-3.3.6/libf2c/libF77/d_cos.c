#include "f2c.h"

#undef abs
#include <math.h>
double
d_cos (doublereal * x)
{
  return (cos (*x));
}
