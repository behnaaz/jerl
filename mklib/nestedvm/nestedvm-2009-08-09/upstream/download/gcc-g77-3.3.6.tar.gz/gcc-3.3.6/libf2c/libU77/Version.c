const char __LIBU77_VERSION__[] = "@(#) LIBU77 VERSION 19980709\n";
