#include "f2c.h"

extern double erfc (double);
double
G77_erfc_0 (real * x)
{
  return (erfc (*x));
}
