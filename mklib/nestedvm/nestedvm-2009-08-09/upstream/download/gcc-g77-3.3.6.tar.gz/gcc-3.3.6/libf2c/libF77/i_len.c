#include "f2c.h"

integer
i_len (char *s __attribute__ ((__unused__)), ftnlen n)
{
  return (n);
}
