#include "f2c.h"

#undef abs
#include <math.h>
double
d_tan (doublereal * x)
{
  return (tan (*x));
}
