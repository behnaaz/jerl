#include "f2c.h"

#undef abs
#include <math.h>
double
r_cos (real * x)
{
  return (cos (*x));
}
