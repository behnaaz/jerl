#include "f2c.h"

extern double erf (double);
double
G77_derf_0 (doublereal * x)
{
  return (erf (*x));
}
