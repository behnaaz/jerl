#include "f2c.h"

integer
i_mod (integer * a, integer * b)
{
  return (*a % *b);
}
