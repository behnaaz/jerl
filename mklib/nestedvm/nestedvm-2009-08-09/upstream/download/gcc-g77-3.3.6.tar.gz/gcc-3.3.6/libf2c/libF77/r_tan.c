#include "f2c.h"

#undef abs
#include <math.h>
double
r_tan (real * x)
{
  return (tan (*x));
}
