double __uitod (unsigned int a)
{
  return a;
}
