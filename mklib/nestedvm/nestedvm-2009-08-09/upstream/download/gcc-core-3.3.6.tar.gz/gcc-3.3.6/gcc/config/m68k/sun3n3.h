#include "m68k/sun3n.h"

/* LINK_SPEC is needed only for SunOS 4.  */

#undef LINK_SPEC
